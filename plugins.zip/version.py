# [file name]: version.py
# -*- coding: utf-8 -*-

import xmpp
import time
import random
import re
import base64

def safe_decode(text):
    """فك ترميز النص بأمان"""
    if text is None:
        return ""
    
    if isinstance(text, str):
        return text
    
    if isinstance(text, bytes):
        try:
            return text.decode('utf-8')
        except UnicodeDecodeError:
            try:
                return text.decode('utf-8', errors='ignore')
            except:
                return str(text, errors='ignore')
    
    return str(text)

def rand10():
    """إنشاء رقم عشوائي مكون من 10 أرقام"""
    return str(random.randint(1000000000, 9999999999))

def extract_source_info(source):
    """استخراج معلومات المصدر من tuple"""
    if isinstance(source, (list, tuple)):
        jid = source[0] if len(source) > 0 else ''
        room = source[1] if len(source) > 1 else ''
        nick = source[2] if len(source) > 2 else ''
    else:
        jid = source
        room = ''
        nick = ''
    return jid, room, nick

def handler_disco(ttype, jid, nick, parameters):
    """معالجة أمر اكتشاف الخدمات"""
    if not parameters:
        return send_msg(ttype, jid, nick, "❌ استخدم: !اكتشف <jid> [عدد] [بحث]")
    
    try:
        parst = parameters.split(' ', 2)
        stop, srch, tojid = '', '', parst[0]
        
        if len(parst) == 1:
            if ttype == 'groupchat': 
                stop = 10
            else: 
                stop = 50
            srch = None
        elif len(parst) > 1:
            try:
                stop = int(parst[1])
                try:
                    srch = parst[2]
                except Exception:
                    srch = None
            except Exception:
                srch = parst[1]
                if ttype == 'groupchat': 
                    stop = 10
                else: 
                    stop = 50
            
            if ttype == 'groupchat':
                if stop > 50: 
                    stop = 50
            else:
                if stop > 250: 
                    stop = 250
        
        iq = xmpp.Iq('get')
        Id = 'disco%s' % (rand10())
        iq.setID(Id)
        iq.addChild('query', {}, [], xmpp.NS_DISCO_ITEMS)
        
        if len(tojid.split('#')) == 2:
            iq.getQuery().setAttr('node', tojid.split('#')[1])
            iq.setTo(tojid.split('#')[0])
        else:
            iq.setTo(tojid)
        
        if ttype != 'null':
            jconn = get_client()
            jconn.SendAndCallForResponse(iq, handler_disco_ext, {'ttype': ttype, 'jid': jid, 'nick': nick, 'stop': stop, 'srch': srch, 'tojid': tojid, 'sId': Id})
        else:
            send_msg(ttype, jid, nick, "🔍 جاري اكتشاف خدمات الخادم...")
            
    except Exception as e:
        send_msg(ttype, jid, nick, f"❌ خطأ في الاكتشاف: {safe_decode(str(e))}")

def handler_disco_ext(coze, res, ttype, jid, nick, stop, srch, tojid, sId):
    """معالجة رد اكتشاف الخدمات"""
    disco = []
    
    if res:
        Id = res.getID()
        if Id != sId:
            return send_msg(ttype, jid, nick, "❌ خطأ في المعرف")
        
        if res.getType() == 'result':
            query = res.getQueryChildren()
            if query:
                for x in query:
                    attrs = x.getAttrs()
                    if 'name' in attrs and 'jid' in attrs:
                        name = attrs.get('name', '')
                        jid_item = attrs.get('jid', '')
                        node = attrs.get('node', '')
                        
                        if name:
                            try:
                                match = re.search(r'^(.*) \((.*)\)$', name)
                                if match:
                                    name_part, desc = match.groups()
                                    disco.append([name_part, jid_item, desc])
                                else:
                                    temp = []
                                    if name:
                                        temp.append(name)
                                    if jid_item and not tojid.count('@'):
                                        temp.append(jid_item)
                                    if node:
                                        temp.append(node)
                                    disco.append(temp)
                            except Exception:
                                disco.append([name, jid_item])
                        else:
                            disco.append([jid_item])
            
            # إزالة التكرارات
            disco_c = []
            for li in disco: 
                if li not in disco_c: 
                    disco_c.append(li)
            disco = disco_c
            
            if disco:
                handler_disco_answ(ttype, jid, nick, stop, disco, srch)
            else:
                send_msg(ttype, jid, nick, "❌ لم يتم العثور على نتائج")
        else:
            send_msg(ttype, jid, nick, "❌ تعذر تنفيذ الاستعلام")
    else:
        send_msg(ttype, jid, nick, "❌ خطأ غير معروف")

def handler_disco_answ(ttype, jid, nick, stop, disco, srch):
    """عرض نتائج الاكتشاف"""
    dis = []
    disco_sorted = sortdis(disco)
    
    for item in disco_sorted:
        if len(item) == 3:
            if srch:
                if srch.endswith('@'):
                    if not item[1].startswith(srch):
                        continue
                else:
                    if srch not in item[0] and srch not in item[1]:
                        continue
            
            dis.append('%s [%s]: %s' % (item[0], item[1], item[2]))
        elif len(item) == 2:
            if srch:
                if srch not in item[0] and srch not in item[1]:
                    continue
            dis.append('%s [%s]' % (item[0], item[1]))
        else:
            if srch:
                if srch not in item[0]:
                    continue
            dis.append(item[0])
        
        if len(dis) == stop:
            break
    
    if dis:
        dis_num = get_num_list(dis)
        if len(disco) != len(dis):
            rep = 'نتائج الاكتشاف (المجموع: %s؛ المعروض: %s):\n\n' % (len(disco), len(dis))
        else:
            rep = 'نتائج الاكتشاف (المجموع: %s):\n\n' % (len(dis))
        rep += '\n'.join(dis_num)
    else:
        rep = '❌ لم يتم العثور على نتائج'
    
    send_msg(ttype, jid, nick, rep)

def sortdis(dis):
    """ترتيب نتائج الاكتشاف"""
    disd, diss, disr = [], [], []
    
    for x in dis:
        try:
            int(x[2])
            disd.append(x)
        except Exception:
            diss.append(x)
    
    disd.sort()
    disd.reverse()
    diss.sort()
    
    for x in disd:
        disr.append(x)
    for x in diss:
        disr.append(x)
        
    return disr

def get_num_list(items):
    """ترقيم العناصر في القائمة"""
    return ['%s. %s' % (i+1, item) for i, item in enumerate(items)]

def parse_subs_par(params):
    """تحليل معاملات الاشتراك"""
    jid, name, access = '', '', ''
    
    if params:
        spltdp = params.strip().split(':', 1)
        
        if len(spltdp) == 1:
            spltdp = spltdp[0].strip().split(' ', 1)
            if len(spltdp) == 1:
                jid = spltdp[0]
            elif len(spltdp) == 2:
                jid = spltdp[0]
                name = spltdp[1]
        elif len(spltdp) == 2:
            jid_name = spltdp[0].strip()
            access = spltdp[1]
            spltdp = jid_name.split(' ', 1)
            if len(spltdp) == 1:
                jid = spltdp[0]
            elif len(spltdp) == 2:
                jid = spltdp[0]
                name = spltdp[1]

    return (jid.strip(), name.strip(), access.strip())

def handler_subscribe(ttype, jid, nick, parameters):
    """معالجة أمر الاشتراك"""
    if not parameters:
        return send_msg(ttype, jid, nick, "❌ استخدم: !اشتراك <jid> [اسم] [صلاحية]")
    
    jid_param, name, access = parse_subs_par(parameters)
    
    if not jid_param:
        return send_msg(ttype, jid, nick, "❌ يرجى تحديد JID صالح")
    
    try:
        # محاكاة عملية الاشتراك
        if '@' in jid_param:
            if access and access.isdigit():
                level = int(access)
                if level > 11:
                    level = 11
            else:
                level = 11
            
            if not name:
                name = jid_param.split('@')[0]
            
            send_msg(ttype, jid, nick, f"✅ تم إرسال طلب التفويض إلى {jid_param} باسم '{name}' مع صلاحية {level}")
        else:
            send_msg(ttype, jid, nick, "❌ يرجى إدخال JID صالح")
    except Exception as e:
        send_msg(ttype, jid, nick, f"❌ خطأ في الإضافة: {str(e)}")

def handler_usubscribe(ttype, jid, nick, parameters):
    """معالجة أمر إلغاء الاشتراك"""
    if not parameters:
        return send_msg(ttype, jid, nick, "❌ استخدم: !الغاءاشتراك <jid>")
    
    jid_param = parameters.strip()
    
    if not jid_param or '@' not in jid_param:
        return send_msg(ttype, jid, nick, "❌ يرجى إدخال JID صالح")
    
    send_msg(ttype, jid, nick, f"✅ تم إلغاء اشتراك وإزالة الحساب {jid_param} من القائمة")

def handler_list_roster(ttype, jid, nick, parameters):
    """عرض قائمة جهات الاتصال"""
    try:
        # محاكاة قائمة جهات الاتصال
        sample_users = [
            {'jid': 'user1@example.com', 'name': 'مستخدم تجريبي ١', 'groups': ['أصدقاء'], 'subscription': 'both'},
            {'jid': 'user2@example.com', 'name': 'مستخدم تجريبي ٢', 'groups': ['عمل'], 'subscription': 'from'},
        ]
        
        if parameters:
            jid_param = parameters.strip()
            filtered = [u for u in sample_users if u['jid'] == jid_param]
            if not filtered:
                send_msg(ttype, jid, nick, "❌ المستخدم غير موجود في القائمة")
                return
            sample_users = filtered
        
        user_list = []
        for user in sample_users:
            user_line = f"المستخدم: {user['name']} <{user['jid']}>\n"
            user_line += f"     المجموعة(ات): {', '.join(user['groups'])}\n"
            user_line += f"     الاشتراك: {user['subscription']}\n"
            user_line += f"     الحالة: متصل\n"
            user_line += f"     الصلاحية: 1\n"
            user_list.append(user_line)
        
        if user_list:
            numbered_list = get_num_list(user_list)
            rep = f"جهات الاتصال (المجموع: {len(numbered_list)}):\n\n" + '\n'.join(numbered_list)
        else:
            rep = "❌ لا توجد جهات اتصال في القائمة"
        
        if ttype == 'groupchat':
            send_msg('chat', jid, nick, rep.strip())
        else:
            send_msg(ttype, jid, nick, rep.strip())
            
    except Exception as e:
        send_msg(ttype, jid, nick, f"❌ خطأ في عرض القائمة: {str(e)}")

def handler_vcardget(ttype, jid, nick, parameters):
    """الحصول على بطاقة التعريف"""
    room = extract_room_from_jid(jid)
    
    if parameters.strip():
        if is_groupchat(room):
            if is_gch_user(room, parameters):
                target_nick = parameters
                target_jid = '%s/%s' % (room, target_nick)
            else:
                target_jid = parameters
                target_nick = target_jid
        else:
            target_jid = parameters
            target_nick = target_jid
    else:
        if is_groupchat(room):
            target_jid = '%s/%s' % (room, nick)
            target_nick = nick
        else:
            target_jid = jid
            target_nick = nick
    
    iq = xmpp.Iq('get')
    Id = 'vcard%s' % (int(time.time()))
    iq.setID(Id)
    iq.addChild('vCard', {}, [], 'vcard-temp')
    iq.setTo(target_jid)
    
    if ttype != 'null':
        jconn = get_client()
        jconn.SendAndCallForResponse(iq, handler_vcardget_answ, {'ttype': ttype, 'jid': jid, 'nick': nick, 'target_nick': target_nick, 'sId': Id})
    else:
        vcard_sample = {
            'name': 'مستخدم تجريبي',
            'nickname': target_nick if target_nick else 'بدون اسم',
            'email': 'user@example.com',
            'desc': 'هذا مستخدم تجريبي'
        }
        return vcard_sample

def handler_vcardget_answ(coze, res, ttype, jid, nick, target_nick, sId):
    """معالجة رد بطاقة التعريف"""
    if not res:
        return send_msg(ttype, jid, nick, "❌ خطأ في الاستعلام")
    
    Id = res.getID()
    if Id != sId:
        return send_msg(ttype, jid, nick, "❌ خطأ في المعرف")
    
    ptype = res.getType()
    if ptype == 'error':
        return send_msg(ttype, jid, nick, "❌ غير مدعوم من قبل عميل المستخدم")
    elif ptype == 'result':
        name, nickname, email, desc = '', '', '', ''
        
        vcard = res.getTag('vCard')
        if vcard:
            children = vcard.getChildren()
            for child in children:
                if child.getName() == 'FN':
                    name = child.getData() or ''
                elif child.getName() == 'NICKNAME':
                    nickname = child.getData() or ''
                elif child.getName() == 'EMAIL':
                    email_child = child.getTag('USERID')
                    if email_child:
                        email = email_child.getData() or ''
                elif child.getName() == 'DESC':
                    desc = child.getData() or ''
        
        if not target_nick:
            rep = 'معلومات من بطاقة التعريف:\n'
        else:
            rep = 'معلومات عن "%s" من بطاقة التعريف:\n' % (target_nick)
        
        if nickname:
            rep += '\nالاسم المستعار: %s' % nickname
        if name:
            rep += '\nالاسم الكامل: %s' % name
        if email:
            rep += '\nالبريد الإلكتروني: %s' % email
        if desc:
            rep += '\nالوصف: %s' % desc
        
        if rep.count('\n') == 1:
            rep = '❌ بطاقة التعريف فارغة'
        
        send_msg(ttype, jid, nick, rep)
    else:
        send_msg(ttype, jid, nick, "❌ غير مدعوم من قبل عميل المستخدم")

def handler_version(ttype, jid, nick, parameters):
    """الحصول على إصدار العميل"""
    room = extract_room_from_jid(jid)
    
    iq = xmpp.Iq('get')
    Id = 'ver%s' % (rand10())
    iq.setID(Id)
    iq.addChild('query', {}, [], 'jabber:iq:version')
    
    if parameters.strip():
        if is_groupchat(room):
            if is_gch_user(room, parameters):
                target_jid = room + '/' + parameters
            else:
                target_jid = parameters
        else:
            target_jid = parameters
    else:
        if is_groupchat(room):
            target_jid = room + '/' + nick
        else:
            target_jid = jid
    
    iq.setTo(target_jid)
    
    if ttype != 'null':
        jconn = get_client()
        jconn.SendAndCallForResponse(iq, handler_version_answ, {'ttype': ttype, 'jid': jid, 'nick': nick, 'target_jid': target_jid, 'sId': Id})
    else:
        version_sample = {
            'name': 'عميل تجريبي',
            'version': '1.0.0',
            'os': 'نظام تشغيل تجريبي'
        }
        return version_sample

def handler_version_answ(coze, res, ttype, jid, nick, target_jid, sId):
    """معالجة رد الإصدار"""
    if not res:
        return send_msg(ttype, jid, nick, "❌ خطأ في الاستعلام")
    
    Id = res.getID()
    if Id != sId:
        return send_msg(ttype, jid, nick, "❌ خطأ في المعرف")
    
    ptype = res.getType()
    if ptype == 'error':
        return send_msg(ttype, jid, nick, "❌ المستخدم غير موجود")
    elif ptype == 'result':
        name, version, os_info = '[لا يوجد اسم]', '[لا يوجد إصدار]', '[لا يوجد نظام]'
        
        query = res.getTag('query')
        if query:
            for child in query.getChildren():
                if child.getName() == 'name':
                    name = child.getData() or name
                elif child.getName() == 'version':
                    version = child.getData() or version
                elif child.getName() == 'os':
                    os_info = child.getData() or os_info  # ✅ تم التصحيح هنا
        
        if '@' in target_jid and '/' not in target_jid:
            rep = 'إصدار الخادم %s:' % target_jid
        else:
            rep = 'إصدار العميل:'
        
        rep += ' %s %s [نظام التشغيل: %s]' % (name, version, os_info)
        send_msg(ttype, jid, nick, rep)
    else:
        send_msg(ttype, jid, nick, "❌ غير مدعوم من قبل عميل المستخدم")

def handler_novcard_res(ttype, jid, nick, parameters):
    """تعيين رد فعل البطاقات الفارغة"""
    room = extract_room_from_jid(jid)
    
    if not is_groupchat(room):
        return send_msg(ttype, jid, nick, "❌ هذا الأمر يستخدم فقط في الغرف")
    
    if parameters:
        param_clean = parameters.strip().lower()
        if param_clean not in ['ignore', 'warn', 'kick', 'ban', 'visitor']:
            return send_msg(ttype, jid, nick, "❌ استخدم: ignore, warn, kick, ban, visitor")
        
        send_msg(ttype, jid, nick, f"✅ تم تعيين رد فعل البطاقات الفارغة إلى {param_clean}")
    else:
        send_msg(ttype, jid, nick, "✅ رد فعل البطاقات الفارغة مضبوط على ignore")

def handler_novcard_mess(ttype, jid, nick, parameters):
    """تعيين رسالة البطاقات الفارغة"""
    room = extract_room_from_jid(jid)
    
    if not is_groupchat(room):
        return send_msg(ttype, jid, nick, "❌ هذا الأمر يستخدم فقط في الغرف")
    
    if parameters:
        send_msg(ttype, jid, nick, "✅ تم تعيين رسالة البطاقات الفارغة")
    else:
        send_msg(ttype, jid, nick, "✅ الرسالة الحالية: املأ بطاقة التعريف الخاصة بك ثم انضم مرة أخرى إلى الغرفة")

# دوال المساعدة المحسنة
def get_client():
    """الحصول على عميل XMPP"""
    from run import client
    return client

def send_msg(ttype, jid, nick, text):
    """إرسال رسالة"""
    from run import send_msg as global_send_msg
    global_send_msg(ttype, jid, nick, text)

def is_groupchat(jid):
    """التحقق إذا كان JID غرفة دردشة"""
    return jid and ('conference' in jid or 'muc' in jid)

def is_gch_user(room, nick):
    """التحقق إذا كان المستخدم موجود في الغرفة"""
    from run import megabase
    if not room or not nick:
        return False
    for entry in megabase:
        if entry[0] == room and entry[1] == nick:
            return True
    return False

def extract_room_from_jid(jid):
    """استخراج اسم الغرفة من JID"""
    if not jid:
        return ''
    if '/' in jid:
        return jid.split('/')[0]
    return jid

def execute():
    """تسجيل أوامر البلجن"""
    commands = [
        (7, 'اكتشف', handler_disco, 1, 'اكتشف خدمات الخادم: !اكتشف <jid> [عدد] [بحث]'),
        (1, 'بطاقة', handler_vcardget, 0, 'عرض بطاقة التعريف: !بطاقة [jid/معرف]'),
        (1, 'اصدار', handler_version, 0, 'عرض إصدار العميل: !اصدار [jid/معرف]'),
        (8, 'اشتراك', handler_subscribe, 1, 'إضافة مستخدم: !اشتراك <jid> [اسم] [صلاحية]'),
        (8, 'الغاءاشتراك', handler_usubscribe, 1, 'إزالة مستخدم: !الغاءاشتراك <jid>'),
        (8, 'قائمة', handler_list_roster, 0, 'عرض قائمة جهات الاتصال: !قائمة [jid]'),
        (8, 'تفعيل_البطاقة', handler_novcard_res, 1, 'تفعيل فحص البطاقات: !تفعيل_البطاقة <ignore/warn/kick/ban/visitor>'),
        (8, 'رسالة_البطاقة', handler_novcard_mess, 1, 'تعيين رسالة البطاقات: !رسالة_البطاقة <رسالة>'),
    ]
    
    return commands